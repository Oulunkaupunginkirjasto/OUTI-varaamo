const passwordRequiredForLoginSelector = () => true;

export default passwordRequiredForLoginSelector;

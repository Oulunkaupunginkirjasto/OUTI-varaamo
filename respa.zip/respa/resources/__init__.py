default_app_config = 'resources.apps.ResourceConfig'

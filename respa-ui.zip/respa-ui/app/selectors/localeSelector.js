const localeSelector = (state) => state.ui.locale.locale;

export default localeSelector;
